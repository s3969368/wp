<?php
include('includes/header.inc');
?>

<?php
include('includes/nav.inc');
?>

<?php
include("includes/db_connect.inc");
?>

<main class="main1">
        <div class="container">
            <div class="textContent1">
                <h1>PETS VICTORIA</h1>
                <h2>WELCOME TO PET <br>ADOPTION</h2>
            </div>
            <img src="images/main.jpeg" alt="main" class="main">
        </div>
</main>

<?php
include('includes/footer.inc');
?>