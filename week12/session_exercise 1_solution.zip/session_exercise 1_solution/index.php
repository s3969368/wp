<?php
$title = "Agent";
include('includes/header.inc');
?>
<h1>Welcome to the Agent database</h1>
<?php
include('includes/nav.inc');
?>
<?php
include('includes/footer.inc');
?>